class Piece:
    def __init__(self, color):
        self.color = color

    def symbol(self):
        raise NotImplementedError

    def valid_moves(self, board, x, y):
        raise NotImplementedError