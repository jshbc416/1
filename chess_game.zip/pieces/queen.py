from .base import Piece


class Queen(Piece):
    def symbol(self):
        return 'Q' if self.color == 'white' else 'q'

    def valid_moves(self, board, x, y):
        moves = []
        directions = [  # 총 8방향
            (-1, 0), (1, 0), (0, -1), (0, 1),       # 상하좌우
            (-1, -1), (-1, 1), (1, -1), (1, 1)      # 대각선
        ]

        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            while board.in_bounds(nx, ny):
                target = board.grid[nx][ny]
                if target is None:
                    moves.append((nx, ny))
                elif target.color != self.color:
                    moves.append((nx, ny))
                    break
                else:
                    break
                nx += dx
                ny += dy

        return moves