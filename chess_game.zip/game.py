from board import Board, algebra_to_index, index_to_algebra
from pieces import Pawn, Knight, Bishop, Rook, Queen, King


class Game:
    def __init__(self):
        self.board = Board()
        self.turn = 'white'
        self.running = True
        self.king_moved = {'white': False, 'black': False}
        self.rook_moved = {
            'white': {'kingside': False, 'queenside': False},
            'black': {'kingside': False, 'queenside': False}
        }

    def start(self):
        while self.running:
            self.board.display()
            print(f"{self.turn}'s turn. (e.g., e2 e4)")
            try:
                user_input = input("Move: ").strip().upper()
                if user_input == '0-0':  # 킹사이드 캐슬링
                    x1, y1 = 4, 0 if self.turn == 'white' else 7
                    x2 = 6
                    self.move(x1, y1, x2, y1)
                    continue
                elif user_input == '0-0-0':  # 퀸사이드 캐슬링
                    x1, y1 = 4, 0 if self.turn == 'white' else 7
                    x2 = 2
                    self.move(x1, y1, x2, y1)
                    continue

                # 일반 수 처리
                pos1, pos2 = user_input.split()
                x1, y1 = algebra_to_index(pos1)
                x2, y2 = algebra_to_index(pos2)
                self.move(x1, y1, x2, y2)

            except Exception:
                print("❌ Invalid input format. Use 'e2 e4' or '0-0'")

    def move(self, x1, y1, x2, y2):
        if not self.board.in_bounds(x1, y1) or not self.board.in_bounds(x2, y2):
            print("❌ Invalid coordinates")
            return

        piece = self.board.grid[x1][y1]
        if not piece:
            print("❌ No piece at start position")
            return
        if piece.color != self.turn:
            print("❌ Not your turn")
            return

        valid = piece.valid_moves(self.board, x1, y1)
        if (x2, y2) not in valid:
            print("❌ Invalid move for that piece")
            return

        # 캐슬링 시도
        if isinstance(piece, King) and abs(x2 - x1) == 2 and y1 == y2:
            if self.can_castle(self.turn, kingside=(x2 > x1)):
                self.perform_castling(self.turn, kingside=(x2 > x1))
                self.switch_turn()
                return
            else:
                print("❌ Cannot castle")
                return

        self.make_move(x1, y1, x2, y2)
        self.check_win(x2, y2)
        self.handle_promotion(x2, y2)
        self.switch_turn()

    def make_move(self, x1, y1, x2, y2):
        piece = self.board.grid[x1][y1]

        # 킹/룩 이동 기록
        if isinstance(piece, King):
            self.king_moved[piece.color] = True
        elif isinstance(piece, Rook):
            if x1 == 0:
                self.rook_moved[piece.color]['queenside'] = True
            elif x1 == 7:
                self.rook_moved[piece.color]['kingside'] = True

        self.board.grid[x2][y2] = piece
        self.board.grid[x1][y1] = None

    def check_win(self, x, y):
        target = self.board.grid[x][y]
        # 도착한 칸에 있는 킹이 **상대 색깔**일 경우에만 승리 처리
        if isinstance(target, King) and target.color != self.turn:
            print(f"🏁 {self.turn} wins! {target.color} King captured.")
            self.running = False

    def handle_promotion(self, x, y):
        piece = self.board.grid[x][y]
        if isinstance(piece, Pawn):
            final_rank = 7 if piece.color == 'white' else 0
            if y == final_rank:
                while True:
                    choice = input("Promote to (Q, R, B, N): ").strip().upper()
                    if choice in ('Q', 'R', 'B', 'N'):
                        break
                    print("❌ Invalid choice. Choose from Q, R, B, N.")
                promoted = {'Q': Queen, 'R': Rook, 'B': Bishop, 'N': Knight}[choice]
                self.board.grid[x][y] = promoted(piece.color)
                print(f"{self.turn}'s pawn promoted to {choice} at {index_to_algebra(x, y)}!")

    def switch_turn(self):
        self.turn = 'black' if self.turn == 'white' else 'white'

    def can_castle(self, color, kingside):
        y = 0 if color == 'white' else 7
        if self.king_moved[color]:
            return False
        if kingside:
            if self.rook_moved[color]['kingside']:
                return False
            return all(self.board.grid[x][y] is None for x in [5, 6])
        else:
            if self.rook_moved[color]['queenside']:
                return False
            return all(self.board.grid[x][y] is None for x in [1, 2, 3])

    def perform_castling(self, color, kingside):
        y = 0 if color == 'white' else 7
        king = self.board.grid[4][y]
        if kingside:
            rook = self.board.grid[7][y]
            self.board.grid[6][y] = king
            self.board.grid[5][y] = rook
            self.board.grid[4][y] = None
            self.board.grid[7][y] = None
        else:
            rook = self.board.grid[0][y]
            self.board.grid[2][y] = king
            self.board.grid[3][y] = rook
            self.board.grid[4][y] = None
            self.board.grid[0][y] = None

        self.king_moved[color] = True
        side = 'kingside' if kingside else 'queenside'
        self.rook_moved[color][side] = True

        print(f"♖♔ {color} castled {side}!")